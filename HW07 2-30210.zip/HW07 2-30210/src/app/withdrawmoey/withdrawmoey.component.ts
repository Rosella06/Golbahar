import { Component } from '@angular/core';

@Component({
  selector: 'app-withdrawmoey',
  templateUrl: './withdrawmoey.component.html',
  styleUrls: ['./withdrawmoey.component.css']
})
export class WithdrawmoeyComponent {

}
