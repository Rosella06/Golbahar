import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WithdrawmoeyComponent } from './withdrawmoey.component';

describe('WithdrawmoeyComponent', () => {
  let component: WithdrawmoeyComponent;
  let fixture: ComponentFixture<WithdrawmoeyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WithdrawmoeyComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WithdrawmoeyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
