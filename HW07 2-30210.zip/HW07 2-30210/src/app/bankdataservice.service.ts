import { Injectable } from '@angular/core';
import { IBankdata } from '../assets/data/bankdata'
@Injectable({
  providedIn: 'root'
})
export class BankdataserviceService {

  constructor() { }
  getData(): IBankdata[] {
    return [{
      accountId: 6,
      accountName: "Rosella",
      accountSurname: "Moday",
      moneyAmount: 650000
    },
    {
      accountId: 8,
      accountName: "Golbahar",
      accountSurname: "Wongmee",
      moneyAmount: 5200000
    },
    {
      accountId: 30,
      accountName: "Roswell",
      accountSurname: "wanwisa",
      moneyAmount: 450000
    }]
  }
}
