export interface IBankdata {
    accountId: number;
    accountName: string;
    accountSurname: string;
    moneyAmount: number;
}